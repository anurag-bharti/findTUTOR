let mongoose = require("mongoose");
let Schema = mongoose.Schema;

let tutorSchema = new Schema({
	name: {
		type: String,
		required: true,
	},
	email: {
		type: String,
    required: true,
	},
  age:{
    type: Number,
    required: true,
  },
  gender:{
    type:String,
    required: true,
  },
  qualification:{
    type:String,
    required: true,
  },
  experience:{
    type:String,
    required: true,
  },
  class:{
    type: Number
  },
  fee:{
    type:String
  },
  classs:{
    type:String
  }
});

module.exports = mongoose.model('Tutor', tutorSchema);
