import React, { Component } from 'react';
import logo from './logo.svg';
import { Link ,Switch, Route} from 'react-router-dom'
import './App.css';
import {Home, Student,Tutor,Login} from './components/index.js'

class App extends Component {
  render() {
    return (
      <div className="App">
        <Switch>
        <Route exact path='/' component={Home}/>
        <Route  path='/student' component={Student}/>
        <Route  path='/Tutor' component={Tutor}/>
        <Route path='/login' component={Login}/>
      </Switch>
      </div>
    );
  }
}

export default App;
