import Home from './Home/Home.js';
import Student from './Student/Student'
import Tutor from './Tutor/Tutor'
import Login from './Login/Login'


export {
  Home,
  Student,
  Tutor,
  Login
}
