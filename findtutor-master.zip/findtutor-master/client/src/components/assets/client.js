export const sendData = (name, age, gender,qualification, fee, experience, email, classs) => {

  fetch('/tutordata', {
  method: 'post',
  body: JSON.stringify({name, age, gender,qualification, fee, experience, email,classs}),
  headers: {
    'Accept': 'application/json',
    'Content-Type': 'application/json'
  }
}).then(res => res.json())
}


export const getData = () => (
    fetch('/tutorinfo', {
    method: 'get',
    headers: {
      'Accept': 'application/json',
      'Content-Type': 'application/json'
    }
  }).then(res => res.json())

)
