import React from 'react'
import { Button, Form, Segment,Divider } from 'semantic-ui-react'
import './Tutor.css'
import {sendData} from '../assets/client'

class  Tutor  extends React.Component {
  constructor(props){
    super(props);
    this.state = {
      name: '',
      age: null,
      gender: '',
      qualification: '',
      fee:'',
      experience: '',
      time: '',
      days: '',
      email: '',
      classs: ''
    }
  }

  handleSubmit(){
  let  {name, age, gender,qualification, fee, experience, email, classs} = this.state;
  sendData(name, age, gender,qualification, fee, experience, email,classs);
  this.setState({
    name: '',
    age: null,
    gender: '',
    qualification: '',
    fee:'',
    experience: '',
    time: '',
    days: '',
    email: '',
    classs: ''
  })
  }

  handleName(e){
    this.setState({
     name: e.target.value
    })
  }
  handleAge(e){
    this.setState({
     age: e.target.value
    })
  }

  handleGender(e){
    this.setState({
     gender: e.target.value
    })
  }

  handleQualification(e){
    this.setState({
     qualification: e.target.value
    })
  }

  handleFee(e){
    this.setState({
     fee: e.target.value
    })
  }

  handleExperience(e){
    this.setState({
     experience: e.target.value
    })
  }

  handleTime(e){
    this.setState({
     time: e.target.value
    })
  }

  handleDays(e){
    this.setState({
     days: e.target.value
    })
  }

  handleEmail(e){
    this.setState({
     email: e.target.value
    })
  }

  handleNumber(e){
  this.setState({
   number: e.target.value
  })
}

  handleClasss(e){
   this.setState({
    classs:e.target.value
  })
}

  render(){
    return (


      <div class="root-student">
        <h3>Register Here...</h3>
      <Divider hidden/>
        <Form size='big'>
          <Form.Group widths='equal'>
            <Form.Field label='Name' control='input' placeholder='Name'
              value={this.state.name} onChange={this.handleName.bind(this)}/>
            <Form.Field label='Gender' control='input' placeholder='Gender'
               value={this.state.gender} onChange={this.handleGender.bind(this)} />
          </Form.Group>
          <Form.Group widths='equal'>
            <Form.Field label='Age' control='input' type='number' placeholder='Age'
              value={this.state.age} onChange={this.handleAge.bind(this)}/>
            <Form.Field label='Qualification' control='input' placeholder='Qualification'
              value={this.state.qualification} onChange={this.handleQualification.bind(this)} />

          </Form.Group>
          <Form.Group widths='equal'>
            <Form.Field label='Fee Expected' control='input' placeholder='Expected Fee'
               value={this.state.fee} onChange={this.handleFee.bind(this)}/>
            <Form.Field label='Experience' control='input' placeholder='Experience'
              value={this.state.experience} onChange={this.handleExperience.bind(this)}/>
          </Form.Group>

          <Form.Group widths='equal'>
            <Form.Field label='Preferred Days' control='input' placeholder='Weekdays/Weekends/All'
              value={this.state.days} onChange={this.handleDays.bind(this)}/>
              <Form.Field label='Email' control='input' type='email' placeholder='Enter email here...'
                value={this.state.value} onChange={this.handleEmail.bind(this)}/>
          </Form.Group>

          <Form.Group widths='equal'>
            <Form.Field label='Preferred Timing' control='input' placeholder='Morning/Evening/Afternoon'
              value={this.state.time} onChange={this.handleTime.bind(this)}/>
              <Form.Field label='Preferred Classes' control='input' placeholder='1-10'
                value={this.state.classs} onChange={this.handleClasss.bind(this)}/>
          </Form.Group>


          <Button type='submit' onClick={this.handleSubmit.bind(this)}>Submit</Button>
          <Divider hidden />
      </Form>
    </div>


    )
  }

}
export default Tutor
