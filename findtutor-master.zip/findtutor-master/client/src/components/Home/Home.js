import React from 'react'
import { Header, Segment, Button,Divider, Container } from 'semantic-ui-react'
import {Student,Tutor,Login} from '../index.js'
import { Link ,Switch, Route} from 'react-router-dom'
import './Home.css'


const Home = () => (
  <div class="root-home">
    <Segment clearing>
      <Header as='h2' floated='left'>
        <img src='./logo.png' ></img>
      </Header>
      <Header as='h2' floated='right'>
        <a href="#ft">Contact</a>
      </Header>
      <Header as='h2' floated='right'>
        <a href="#ab">About Us</a>
      </Header>

    </Segment>
    <Divider hidden />
    <Divider hidden />
    <div class="purpose">
    <ul>
      <li><p>Say NO to "Paid Agents"</p></li>
      <li><p>NO More Meddling</p></li>
      <li><p>Quality Education at your doorstep!</p></li>
    </ul>
    </div>
    <Divider hidden />
    <div id="content">
      <br/><br/>
      <h2>I am a :</h2>
      <Divider hidden />
      <Link to='/login'><Button secondary size='huge'>Student/Parent</Button></Link>
      <Link to='/Tutor'><Button secondary size='huge'>Tutor</Button></Link>
    </div>

  <div class="about" id="ab">

    <Container text>

    <h3>
      We, at findTUTOR, are trying our best to remove the interference from middle
      men in the field of Education and protecting the sanctity of this very field.
      We aim to deliver effective and quality education without any undue cost.
      We are not doing this for any monetary benefits and thus we will not be charging
      any amount either from the Tutors or the Students for this purpose, as we
      understand that it indirectly affects the quality of the education one receives.
      Our venture is merely for a social cause.
    </h3>
    </Container>
</div>

  <div class="footer" id="ft">
    <p> Follow @findTUTOR on Twitter for the latest news.
    For other inquiries, you may email us at findTUTOR@outlook.in</p>
    <p>Copyright 2008-2018 Tapbots, LLC. All Rights Reserved.</p>
  </div>
</div>
)


export default Home
