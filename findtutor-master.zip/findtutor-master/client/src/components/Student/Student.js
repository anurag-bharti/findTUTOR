import React from 'react'
import { Button, Form, Segment,Divider } from 'semantic-ui-react'
import {getData} from '../assets/client'
import './Student.css'
import { Card, Icon, Image ,Input} from 'semantic-ui-react'


class Student extends React.Component {
constructor(props){
  super(props);
  this.state= {
    data: ''
  }
}

componentWillMount() {
  getData().then( (d,e) => {
    console.log(d)
    this.setState({data: d})
  })
}
  render(){


    return (
  <div className="root-student">

 <h2>Search Tutors...</h2>
  <Input size='big' icon='search' placeholder='Search...' />
  <Divider hidden />
    {
      this.state.data ? (
       <Card.Group>
         {
       this.state.data.map(v=>(
         <Card>
           <Image src='/assets/images/avatar/large/matthew.png' />
           <Card.Content>
             <Card.Header>
               {v.name}
             </Card.Header>
             <Card.Meta>
               <span className='date'>
                 <div>Age : {v.age}</div>
                 <div>Gender:{v.gender}</div>
                 <div>Preferred Classes: {v.classs}</div>
                 <div>Email : {v.email}</div>
                 <div>Experience : {v.experience} </div>
                 <div>Qualification : {v.qualification}</div>
                 <div>Fees: {v.fee}</div>
               </span>
             </Card.Meta>
           </Card.Content>
         </Card>
       ))}
 </Card.Group>
): 'loading...'
}</div>
    )
  }

}
export default Student
