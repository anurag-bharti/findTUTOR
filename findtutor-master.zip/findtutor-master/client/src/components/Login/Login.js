import React from 'react'
import { Button, Form, Segment } from 'semantic-ui-react'
import { Link ,Switch, Route} from 'react-router-dom'
import './Login.css'
const Login = () => (
  <div className='login-root'>
    <h2>Please Login to proceed....</h2>
  <Segment inverted>
    <Form inverted>
      <Form.Group widths='equal'>
        <Form.Input fluid label='Email 'type="email" placeholder='Email' />
        <Form.Input fluid label='Password' type="password" placeholder='Password' />
      </Form.Group>

      <Form.Checkbox label='I agree to the Terms and Conditions.' />
      <Link to='/student'><Button secondary size='huge'>Submit</Button></Link>
    </Form>
  </Segment>
</div>
)
export default Login
