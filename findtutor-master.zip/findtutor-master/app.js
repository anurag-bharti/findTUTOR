var express = require('express');
var path = require('path');
var favicon = require('serve-favicon');
var logger = require('morgan');
var cookieParser = require('cookie-parser');
var bodyParser = require('body-parser');

var index = require('./routes/index');
var users = require('./routes/users');
var basicAuth = require('express-basic-auth');
var mongoose = require('mongoose');
var Models = require('./Model/users');
var app = express();


mongoose.connect('mongodb://hemant:12345@ds247327.mlab.com:47327/orion');
//  app.use(basicAuth({
//     users: { 'admin': 'supersecret' }
// }))

// view engine setup
//app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'pug');

// uncomment after placing your favicon in /public
//app.use(favicon(path.join(__dirname, 'public', 'favicon.ico')));
//app.use(express.static(path.join(__dirname, 'client', 'build')));
app.use(logger('dev'));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));
app.use(cookieParser());
//app.use(express.static(path.join(__dirname, 'public')));
app.get('/', (req,res) => {
  res.send('hi')
})

app.get('/tutorinfo', (req,res)=> {
  Models.find({}, function(err, users) {
  var userMap = [];

  users.forEach(function(user) {
    userMap.push(user);
  });
  res.send(userMap);
});
})

app.post('/tutordata', (req,res) => {
  let {name, age, gender,qualification, fee, experience, email,classs} = req.body;

let tutor = new Models({name, age, gender,qualification, fee, experience, email,classs});
tutor.save().then(() => console.log('saved'));
})

app.get('*', (req,res) => {
  res.send('404')
})


// catch 404 and forward to error handler
app.use(function(req, res) {
  var err = new Error('Not Found');
  err.status = 404;
});



app.listen(3001);
module.exports = app;
